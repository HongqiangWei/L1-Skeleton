
/* texture.h - by David Blythe, SGI */

/* Simple SGI .bw image file loader routine. */

extern unsigned char * load_luminance(
  char *name,
  int *width,
  int *height,
  int *components);

